import React, { useContext } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Switch,
  Alert,
  ScrollView,
} from 'react-native';
import { StatusBar } from 'expo-status-bar';
import Icon from 'react-native-vector-icons/MaterialIcons';
import { AppContext } from '../context/AppContext';
import { clearAllData } from '../utils/storage';

const SettingsScreen = ({ navigation }) => {
  const { isDarkTheme, toggleTheme, logout } = useContext(AppContext);

  const handleLogout = () => {
    Alert.alert(
      'Logout',
      'Are you sure you want to logout?',
      [
        { text: 'Cancel', style: 'cancel' },
        { 
          text: 'Logout', 
          style: 'destructive',
          onPress: () => {
            logout();
             
          }
        },
      ]
    );
  };

  const handleResetData = () => {
    Alert.alert(
      'Reset Data',
      'This will clear all your saved data. Are you sure?',
      [
        { text: 'Cancel', style: 'cancel' },
        { 
          text: 'Reset', 
          style: 'destructive',
          onPress: async () => {
            await clearAllData();
            Alert.alert('Success', 'All data has been cleared');
            logout();
           
          }
        },
      ]
    );
  };

  const SettingItem = ({ icon, title, onPress, isSwitch, switchValue, onSwitchChange, danger }) => (
    <TouchableOpacity 
      style={[styles.settingItem, isDarkTheme && styles.darkSettingItem]} 
      onPress={onPress}
      disabled={isSwitch}
    >
      <View style={styles.settingLeft}>
        <Icon name={icon} size={24} color={danger ? '#FF3B30' : '#007AFF'} />
        <Text style={[styles.settingTitle, isDarkTheme && styles.darkText, danger && styles.dangerText]}>
          {title}
        </Text>
      </View>
      {isSwitch ? (
        <Switch
          value={switchValue}
          onValueChange={onSwitchChange}
          trackColor={{ false: '#767577', true: '#81b0ff' }}
          thumbColor={switchValue ? '#007AFF' : '#f4f3f4'}
        />
      ) : (
        <Icon name="chevron-right" size={24} color={isDarkTheme ? '#888' : '#999'} />
      )}
    </TouchableOpacity>
  );

  return (
    <ScrollView style={[styles.container, isDarkTheme && styles.darkContainer]}>
      <StatusBar style={isDarkTheme ? 'light' : 'dark'} />
      
      <View style={[styles.content, isDarkTheme && styles.darkContent]}>
        <View style={styles.section}>
          <Text style={[styles.sectionTitle, isDarkTheme && styles.darkSectionTitle]}>Preferences</Text>
          <SettingItem
            icon="brightness-6"
            title="Dark Mode"
            isSwitch={true}
            switchValue={isDarkTheme}
            onSwitchChange={toggleTheme}
          />
        </View>

        <View style={styles.section}>
          <Text style={[styles.sectionTitle, isDarkTheme && styles.darkSectionTitle]}>Data Management</Text>
          <SettingItem
            icon="delete-sweep"
            title="Reset All Data"
            onPress={handleResetData}
            danger={true}
          />
        </View>

        <View style={styles.section}>
          <Text style={[styles.sectionTitle, isDarkTheme && styles.darkSectionTitle]}>Account</Text>
          <SettingItem
            icon="logout"
            title="Logout"
            onPress={handleLogout}
            danger={true}
          />
        </View>

        <View style={styles.versionContainer}>
          <Text style={[styles.versionText, isDarkTheme && styles.darkSubText]}>
            Version 1.0.0
          </Text>
        </View>
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  darkContainer: {
    backgroundColor: '#121212',
  },
  content: {
    flex: 1,
  },
  darkContent: {
    backgroundColor: '#121212',
  },
  section: {
    marginTop: 20,
  },
  sectionTitle: {
    fontSize: 14,
    fontWeight: '600',
    color: '#666',
    marginLeft: 20,
    marginBottom: 10,
    textTransform: 'uppercase',
  },
  darkSectionTitle: {
    color: '#aaa',
  },
  settingItem: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: '#fff',
    paddingVertical: 15,
    paddingHorizontal: 20,
    marginBottom: 1,
  },
  darkSettingItem: {
    backgroundColor: '#1e1e1e',
  },
  settingLeft: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  settingTitle: {
    fontSize: 16,
    marginLeft: 15,
    color: '#333',
  },
  darkText: {
    color: '#fff',
  },
  dangerText: {
    color: '#FF3B30',
  },
  versionContainer: {
    alignItems: 'center',
    marginTop: 40,
    marginBottom: 20,
  },
  versionText: {
    fontSize: 12,
    color: '#999',
  },
  darkSubText: {
    color: '#aaa',
  },
});

export default SettingsScreen;