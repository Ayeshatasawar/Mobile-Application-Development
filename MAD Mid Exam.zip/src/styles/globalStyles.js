import { StyleSheet } from 'react-native';

export const globalStyles = StyleSheet.create({
  // Container Styles
  container: {
    flex: 1,
    padding: 20,
  },
  centerContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  rowContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  spaceBetween: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  
  // Typography
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    fontFamily: 'Poppins-Bold',
  },
  heading: {
    fontSize: 24,
    fontWeight: 'bold',
    fontFamily: 'Poppins-Bold',
  },
  subheading: {
    fontSize: 20,
    fontWeight: '600',
    fontFamily: 'Poppins-SemiBold',
  },
  bodyText: {
    fontSize: 16,
    fontFamily: 'Poppins-Regular',
  },
  smallText: {
    fontSize: 12,
    fontFamily: 'Poppins-Regular',
  },
  caption: {
    fontSize: 10,
    fontFamily: 'Poppins-Regular',
  },
  
  // Text Colors
  textPrimary: {
    color: '#333333',
  },
  textSecondary: {
    color: '#666666',
  },
  textWhite: {
    color: '#FFFFFF',
  },
  textDanger: {
    color: '#FF3B30',
  },
  textSuccess: {
    color: '#4CAF50',
  },
  textWarning: {
    color: '#FF9800',
  },
  textInfo: {
    color: '#2196F3',
  },
  
  // Button Styles
  button: {
    paddingVertical: 12,
    paddingHorizontal: 20,
    borderRadius: 8,
    alignItems: 'center',
    justifyContent: 'center',
  },
  buttonPrimary: {
    backgroundColor: '#007AFF',
  },
  buttonSecondary: {
    backgroundColor: '#6C757D',
  },
  buttonSuccess: {
    backgroundColor: '#4CAF50',
  },
  buttonDanger: {
    backgroundColor: '#FF3B30',
  },
  buttonOutline: {
    backgroundColor: 'transparent',
    borderWidth: 1,
    borderColor: '#007AFF',
  },
  buttonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '600',
  },
  buttonTextOutline: {
    color: '#007AFF',
  },
  
  // Input Styles
  input: {
    height: 50,
    borderWidth: 1,
    borderColor: '#DDDDDD',
    borderRadius: 8,
    paddingHorizontal: 15,
    fontSize: 16,
    backgroundColor: '#FFFFFF',
  },
  inputFocused: {
    borderColor: '#007AFF',
    borderWidth: 2,
  },
  inputError: {
    borderColor: '#FF3B30',
  },
  textArea: {
    height: 100,
    textAlignVertical: 'top',
  },
  label: {
    fontSize: 14,
    fontWeight: '500',
    marginBottom: 8,
    color: '#333333',
  },
  
  // Card Styles
  card: {
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    padding: 15,
    marginVertical: 8,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  cardElevated: {
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    padding: 15,
    marginVertical: 8,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.15,
    shadowRadius: 6,
    elevation: 5,
  },
  
  // Spacing
  m0: { margin: 0 },
  m5: { margin: 5 },
  m10: { margin: 10 },
  m15: { margin: 15 },
  m20: { margin: 20 },
  mt5: { marginTop: 5 },
  mt10: { marginTop: 10 },
  mt15: { marginTop: 15 },
  mt20: { marginTop: 20 },
  mb5: { marginBottom: 5 },
  mb10: { marginBottom: 10 },
  mb15: { marginBottom: 15 },
  mb20: { marginBottom: 20 },
  ml5: { marginLeft: 5 },
  ml10: { marginLeft: 10 },
  ml15: { marginLeft: 15 },
  ml20: { marginLeft: 20 },
  mr5: { marginRight: 5 },
  mr10: { marginRight: 10 },
  mr15: { marginRight: 15 },
  mr20: { marginRight: 20 },
  
  p0: { padding: 0 },
  p5: { padding: 5 },
  p10: { padding: 10 },
  p15: { padding: 15 },
  p20: { padding: 20 },
  pt5: { paddingTop: 5 },
  pt10: { paddingTop: 10 },
  pt15: { paddingTop: 15 },
  pt20: { paddingTop: 20 },
  pb5: { paddingBottom: 5 },
  pb10: { paddingBottom: 10 },
  pb15: { paddingBottom: 15 },
  pb20: { paddingBottom: 20 },
  pl5: { paddingLeft: 5 },
  pl10: { paddingLeft: 10 },
  pl15: { paddingLeft: 15 },
  pl20: { paddingLeft: 20 },
  pr5: { paddingRight: 5 },
  pr10: { paddingRight: 10 },
  pr15: { paddingRight: 15 },
  pr20: { paddingRight: 20 },
  
  // Flex Layout
  flex1: { flex: 1 },
  flex2: { flex: 2 },
  flex3: { flex: 3 },
  flexRow: {
    flexDirection: 'row',
  },
  flexColumn: {
    flexDirection: 'column',
  },
  justifyContentCenter: {
    justifyContent: 'center',
  },
  justifyContentFlexStart: {
    justifyContent: 'flex-start',
  },
  justifyContentFlexEnd: {
    justifyContent: 'flex-end',
  },
  justifyContentSpaceBetween: {
    justifyContent: 'space-between',
  },
  justifyContentSpaceAround: {
    justifyContent: 'space-around',
  },
  alignItemsCenter: {
    alignItems: 'center',
  },
  alignItemsFlexStart: {
    alignItems: 'flex-start',
  },
  alignItemsFlexEnd: {
    alignItems: 'flex-end',
  },
  
  // Border Radius
  rounded0: { borderRadius: 0 },
  rounded5: { borderRadius: 5 },
  rounded10: { borderRadius: 10 },
  rounded15: { borderRadius: 15 },
  rounded20: { borderRadius: 20 },
  rounded25: { borderRadius: 25 },
  roundedCircle: { borderRadius: 999 },
  
  // Shadows
  shadowLight: {
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 2,
  },
  shadowMedium: {
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.15,
    shadowRadius: 4,
    elevation: 4,
  },
  shadowHeavy: {
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.2,
    shadowRadius: 6,
    elevation: 6,
  },
  
  // Background Colors
  bgPrimary: {
    backgroundColor: '#007AFF',
  },
  bgWhite: {
    backgroundColor: '#FFFFFF',
  },
  bgLight: {
    backgroundColor: '#F5F5F5',
  },
  bgDark: {
    backgroundColor: '#121212',
  },
  bgSuccess: {
    backgroundColor: '#4CAF50',
  },
  bgDanger: {
    backgroundColor: '#FF3B30',
  },
  bgWarning: {
    backgroundColor: '#FF9800',
  },
  
  // Divider
  divider: {
    height: 1,
    backgroundColor: '#E0E0E0',
    marginVertical: 10,
  },
  dividerHorizontal: {
    width: 1,
    backgroundColor: '#E0E0E0',
    marginHorizontal: 10,
  },
  
  // Image Styles
  imageCover: {
    width: '100%',
    height: '100%',
    resizeMode: 'cover',
  },
  imageContain: {
    width: '100%',
    height: '100%',
    resizeMode: 'contain',
  },
  avatarSmall: {
    width: 40,
    height: 40,
    borderRadius: 20,
  },
  avatarMedium: {
    width: 60,
    height: 60,
    borderRadius: 30,
  },
  avatarLarge: {
    width: 100,
    height: 100,
    borderRadius: 50,
  },
  
  // Screen Specific
  screenContainer: {
    flex: 1,
    backgroundColor: '#F5F5F5',
  },
  darkScreenContainer: {
    flex: 1,
    backgroundColor: '#121212',
  },
  
  // Header Styles
  header: {
    backgroundColor: '#007AFF',
    paddingVertical: 15,
    paddingHorizontal: 20,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#FFFFFF',
  },
  
  // List Styles
  listItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 12,
    paddingHorizontal: 15,
    backgroundColor: '#FFFFFF',
    borderBottomWidth: 1,
    borderBottomColor: '#E0E0E0',
  },
  listItemPressed: {
    backgroundColor: '#F0F0F0',
  },
});

// Theme-based styles (to be used with useContext)
export const getThemeStyles = (isDarkTheme) => ({
  container: {
    backgroundColor: isDarkTheme ? '#121212' : '#F5F5F5',
  },
  card: {
    backgroundColor: isDarkTheme ? '#1E1E1E' : '#FFFFFF',
  },
  text: {
    color: isDarkTheme ? '#FFFFFF' : '#333333',
  },
  textSecondary: {
    color: isDarkTheme ? '#AAAAAA' : '#666666',
  },
  input: {
    backgroundColor: isDarkTheme ? '#2C2C2C' : '#FFFFFF',
    color: isDarkTheme ? '#FFFFFF' : '#333333',
    borderColor: isDarkTheme ? '#444444' : '#DDDDDD',
  },
  header: {
    backgroundColor: isDarkTheme ? '#1A1A1A' : '#007AFF',
  },
  tabBar: {
    backgroundColor: isDarkTheme ? '#1A1A1A' : '#FFFFFF',
  },
  divider: {
    backgroundColor: isDarkTheme ? '#333333' : '#E0E0E0',
  },
  icon: {
    color: isDarkTheme ? '#FFFFFF' : '#333333',
  },
  buttonPrimary: {
    backgroundColor: isDarkTheme ? '#0A84FF' : '#007AFF',
  },
});

// Color Palette
export const colors = {
  primary: '#007AFF',
  secondary: '#6C757D',
  success: '#4CAF50',
  danger: '#FF3B30',
  warning: '#FF9800',
  info: '#2196F3',
  light: '#F5F5F5',
  dark: '#121212',
  white: '#FFFFFF',
  black: '#000000',
  gray: '#808080',
  grayLight: '#E0E0E0',
  grayDark: '#666666',
  
  // Dark Theme Colors
  darkBackground: '#121212',
  darkSurface: '#1E1E1E',
  darkCard: '#2C2C2C',
  darkText: '#FFFFFF',
  darkTextSecondary: '#AAAAAA',
};

// Typography Constants
export const typography = {
  fontFamily: {
    regular: 'Poppins-Regular',
    bold: 'Poppins-Bold',
    semiBold: 'Poppins-SemiBold',
  },
  fontSize: {
    xs: 10,
    sm: 12,
    md: 14,
    base: 16,
    lg: 18,
    xl: 20,
    xxl: 24,
    xxxl: 28,
    huge: 32,
  },
  lineHeight: {
    xs: 14,
    sm: 16,
    md: 20,
    base: 24,
    lg: 26,
    xl: 28,
    xxl: 32,
    xxxl: 36,
  },
};

// Spacing Constants
export const spacing = {
  xs: 4,
  sm: 8,
  md: 12,
  base: 16,
  lg: 20,
  xl: 24,
  xxl: 32,
  xxxl: 40,
};

// Border Radius Constants
export const borderRadius = {
  xs: 4,
  sm: 8,
  md: 12,
  base: 16,
  lg: 20,
  xl: 24,
  xxl: 32,
  circle: 999,
};

// Shadow Constants
export const shadows = {
  light: {
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 2,
  },
  medium: {
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.15,
    shadowRadius: 4,
    elevation: 4,
  },
  heavy: {
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.2,
    shadowRadius: 6,
    elevation: 6,
  },
};

// Helper function to combine styles
export const combineStyles = (...styles) => {
  return Object.assign({}, ...styles);
};

// Export all as default
export default {
  globalStyles,
  getThemeStyles,
  colors,
  typography,
  spacing,
  borderRadius,
  shadows,
  combineStyles,
};