import AsyncStorage from '@react-native-async-storage/async-storage';

// Save user data
export const storeUserData = async (userData) => {
  try {
    const usersJson = await AsyncStorage.getItem('studentUsers');
    let users = usersJson ? JSON.parse(usersJson) : [];
    
    // Check if user already exists
    const existingUserIndex = users.findIndex(u => u.email === userData.email);
    
    if (existingUserIndex !== -1) {
      users[existingUserIndex] = userData;
    } else {
      users.push(userData);
    }
    
    await AsyncStorage.setItem('studentUsers', JSON.stringify(users));
    await AsyncStorage.setItem('currentUser', JSON.stringify(userData));
    return true;
  } catch (error) {
    console.error('Error storing user data:', error);
    return false;
  }
};

// Check if user exists
export const checkUserExists = async (email, password) => {
  try {
    const usersJson = await AsyncStorage.getItem('studentUsers');
    const users = usersJson ? JSON.parse(usersJson) : [];
    
    const user = users.find(u => u.email === email && u.password === password);
    
    if (user) {
      await AsyncStorage.setItem('currentUser', JSON.stringify(user));
      return { exists: true, userData: user };
    }
    
    return { exists: false, userData: null };
  } catch (error) {
    console.error('Error checking user:', error);
    return { exists: false, userData: null };
  }
};

// Get current user data
export const getUserData = async () => {
  try {
    const userJson = await AsyncStorage.getItem('currentUser');
    return userJson ? JSON.parse(userJson) : null;
  } catch (error) {
    console.error('Error getting user data:', error);
    return null;
  }
};

// Update user data - FIXED VERSION
export const updateUserData = async (updatedData) => {
  try {
    // Get all users
    const usersJson = await AsyncStorage.getItem('studentUsers');
    let users = usersJson ? JSON.parse(usersJson) : [];
    
    // Find and update user
    const userIndex = users.findIndex(u => u.email === updatedData.email);
    
    if (userIndex !== -1) {
      users[userIndex] = updatedData;
      await AsyncStorage.setItem('studentUsers', JSON.stringify(users));
      await AsyncStorage.setItem('currentUser', JSON.stringify(updatedData));
      return true;
    } else {
      // If user not found, add as new user
      users.push(updatedData);
      await AsyncStorage.setItem('studentUsers', JSON.stringify(users));
      await AsyncStorage.setItem('currentUser', JSON.stringify(updatedData));
      return true;
    }
  } catch (error) {
    console.error('Error updating user data:', error);
    return false;
  }
};

// Update theme
export const updateTheme = async (isDark) => {
  try {
    await AsyncStorage.setItem('isDarkTheme', JSON.stringify(isDark));
    return true;
  } catch (error) {
    console.error('Error saving theme:', error);
    return false;
  }
};

// Get theme
export const getTheme = async () => {
  try {
    const themeJson = await AsyncStorage.getItem('isDarkTheme');
    return themeJson ? JSON.parse(themeJson) : false;
  } catch (error) {
    console.error('Error getting theme:', error);
    return false;
  }
};