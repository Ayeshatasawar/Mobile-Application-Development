import React, { useState } from 'react';
import { View, Text, Image, TextInput } from 'react-native';
import styles from '../styles';

export default function Profile() {
  const [name, setName] = useState('');
  const [age, setAge] = useState('');

  return (
    <View style={styles.container}>
      <Image 
        source={{uri: 'https://example.com/profile.jpg'}} 
        style={{width: 100, height: 100, borderRadius: 50, marginBottom: 20}}
      />
      <TextInput
        style={styles.input}
        placeholder="Name"
        value={name}
        onChangeText={setName}
      />
      <TextInput
        style={styles.input}
        placeholder="Age"
        value={age}
        onChangeText={setAge}
        keyboardType="numeric"
      />

      <Text style={{marginTop: 20, fontSize: 18}}>Name: {name}</Text>
      <Text style={{fontSize: 18}}>Age: {age}</Text>
    </View>
  );
}