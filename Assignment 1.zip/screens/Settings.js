import React, { useState } from 'react';
import { View, Text, Switch } from 'react-native';
import styles from '../styles';

export default function Settings() {
  const [isDark, setIsDark] = useState(false);

  return (
    <View style={[styles.container, {backgroundColor: isDark ? '#333' : '#fff'}]}>
      <Text style={[styles.title, {color: isDark ? '#fff' : '#000'}]}>
        {isDark ? 'Dark Mode' : 'Light Mode'}
      </Text>
      <Switch value={isDark} onValueChange={setIsDark} />
    </View>
  );
}