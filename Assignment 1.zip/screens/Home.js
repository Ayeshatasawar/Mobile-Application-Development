import React from 'react';
import { View, Text, ImageBackground, TouchableOpacity } from 'react-native';
import styles from '../styles';

export default function Home({ navigation }) {
  return (
    <ImageBackground 
      source={{uri: 'https://example.com/background.jpg'}} 
      style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}
    >
      <Text style={styles.title}>Student App</Text>

      <TouchableOpacity style={styles.button} onPress={() => navigation.navigate('Profile')}>
        <Text style={styles.buttonText}>Profile</Text>
      </TouchableOpacity>

      <TouchableOpacity style={styles.button} onPress={() => navigation.navigate('Settings')}>
        <Text style={styles.buttonText}>Settings</Text>
      </TouchableOpacity>

      <TouchableOpacity style={styles.button} onPress={() => navigation.navigate('Contact')}>
        <Text style={styles.buttonText}>Contact</Text>
      </TouchableOpacity>
    </ImageBackground>
  );
}