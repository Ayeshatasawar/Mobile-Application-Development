import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  FlatList,
  ActivityIndicator,
  StyleSheet,
  TouchableOpacity,
  StatusBar,
  Dimensions,
  Modal,
  ScrollView,
  Image
} from 'react-native';

const { width, height } = Dimensions.get('window');

export default function MovieScreen() {
  const [loading, setLoading] = useState(true);
  const [movies, setMovies] = useState([]);
  const [error, setError] = useState(null);
  const [selectedMovie, setSelectedMovie] = useState(null);
  const [modalVisible, setModalVisible] = useState(false);

  useEffect(() => {
    fetchMovies();
  }, []);

  const fetchMovies = async () => {
    try {
      setLoading(true);
      setError(null);
      const response = await fetch('https://reactnative.dev/movies.json');
      
      if (!response.ok) {
        throw new Error('Failed to fetch movies');
      }
      
      const json = await response.json();
      
      // Add enhanced data for better display
      const enhancedMovies = json.movies.map((movie, index) => ({
        ...movie,
        id: index.toString(),
        rating: (Math.random() * 2 + 3).toFixed(1),
        genre: getRandomGenre(),
        description: getRandomDescription(),
        posterColor: getRandomColor()
      }));
      
      setMovies(enhancedMovies);
    } catch (error) {
      console.error(error);
      setError('Unable to load movies. Please check your connection.');
    } finally {
      setLoading(false);
    }
  };

  const getRandomGenre = () => {
    const genres = ['Action', 'Drama', 'Comedy', 'Thriller', 'Romance', 'Sci-Fi', 'Horror', 'Adventure'];
    return genres[Math.floor(Math.random() * genres.length)];
  };

  const getRandomDescription = () => {
    const descriptions = [
      'A captivating journey through imagination and reality that will leave you speechless.',
      'An unforgettable story that will touch your heart and inspire your soul.',
      'Action-packed adventure from start to finish with breathtaking visual effects.',
      'A cinematic masterpiece that defines the genre and sets new standards.',
      'Heartwarming tale of love, friendship, and the power of dreams.',
      'Edge-of-your-seat thriller with unexpected twists and turns.',
      'A thought-provoking drama that explores the depths of human emotions.',
      'An epic saga of courage, sacrifice, and redemption.'
    ];
    return descriptions[Math.floor(Math.random() * descriptions.length)];
  };

  const getRandomColor = () => {
    const colors = ['#FF6B6B', '#4ECDC4', '#45B7D1', '#96CEB4', '#FFEAA7', '#DDA0DD', '#98D8C8', '#F7DC6F'];
    return colors[Math.floor(Math.random() * colors.length)];
  };

  const renderMovieCard = ({ item, index }) => (
    <TouchableOpacity
      activeOpacity={0.9}
      onPress={() => {
        setSelectedMovie(item);
        setModalVisible(true);
      }}
      style={styles.movieCard}
    >
      <View style={[styles.moviePoster, { backgroundColor: item.posterColor }]}>
        <Text style={styles.moviePosterEmoji}>🎬</Text>
      </View>
      <View style={styles.movieInfo}>
        <View style={styles.movieHeader}>
          <Text style={styles.movieNumber}>#{index + 1}</Text>
          <View style={styles.ratingContainer}>
            <Text style={styles.ratingStar}>⭐</Text>
            <Text style={styles.ratingText}>{item.rating}</Text>
          </View>
        </View>
        <Text style={styles.movieTitle} numberOfLines={2}>
          {item.title}
        </Text>
        <View style={styles.movieMeta}>
          <View style={styles.metaBadge}>
            <Text style={styles.metaBadgeText}>📅 {item.releaseYear}</Text>
          </View>
          <View style={styles.metaBadge}>
            <Text style={styles.metaBadgeText}>🎭 {item.genre}</Text>
          </View>
        </View>
      </View>
      <View style={styles.playIcon}>
        <Text style={styles.playIconText}>▶</Text>
      </View>
    </TouchableOpacity>
  );

  const renderHeader = () => (
    <View style={styles.header}>
      <StatusBar barStyle="light-content" backgroundColor="#1a1a2e" />
      <View style={styles.headerContent}>
        <Text style={styles.headerEmoji}>🎬</Text>
        <Text style={styles.headerTitle}>CineVerse</Text>
        <Text style={styles.headerSubtitle}>Discover amazing films</Text>
      </View>
      <View style={styles.statsContainer}>
        <View style={styles.statBox}>
          <Text style={styles.statNumber}>{movies.length}</Text>
          <Text style={styles.statLabel}>Movies</Text>
        </View>
        <View style={styles.statDivider} />
        <View style={styles.statBox}>
          <Text style={styles.statNumber}>
            {[...new Set(movies.map(m => m.genre))].length}
          </Text>
          <Text style={styles.statLabel}>Genres</Text>
        </View>
        <View style={styles.statDivider} />
        <View style={styles.statBox}>
          <Text style={styles.statNumber}>HD</Text>
          <Text style={styles.statLabel}>Quality</Text>
        </View>
      </View>
    </View>
  );

  const renderMovieModal = () => (
    <Modal
      animationType="slide"
      transparent={true}
      visible={modalVisible}
      onRequestClose={() => setModalVisible(false)}
    >
      <View style={styles.modalOverlay}>
        <View style={styles.modalContent}>
          <ScrollView showsVerticalScrollIndicator={false}>
            {selectedMovie && (
              <>
                <TouchableOpacity
                  style={styles.modalClose}
                  onPress={() => setModalVisible(false)}
                >
                  <Text style={styles.modalCloseText}>✕</Text>
                </TouchableOpacity>
                
                <View style={[styles.modalPoster, { backgroundColor: selectedMovie.posterColor }]}>
                  <Text style={styles.modalPosterEmoji}>🎬</Text>
                  <Text style={styles.modalPosterText}>Now Showing</Text>
                </View>
                
                <View style={styles.modalInfo}>
                  <Text style={styles.modalTitle}>{selectedMovie.title}</Text>
                  
                  <View style={styles.modalMetaRow}>
                    <View style={styles.modalMetaItem}>
                      <Text style={styles.modalMetaIcon}>📅</Text>
                      <Text style={styles.modalMetaText}>
                        {selectedMovie.releaseYear}
                      </Text>
                    </View>
                    <View style={styles.modalMetaItem}>
                      <Text style={styles.modalMetaIcon}>⭐</Text>
                      <Text style={styles.modalMetaText}>
                        {selectedMovie.rating} / 5.0
                      </Text>
                    </View>
                    <View style={styles.modalMetaItem}>
                      <Text style={styles.modalMetaIcon}>🎭</Text>
                      <Text style={styles.modalMetaText}>
                        {selectedMovie.genre}
                      </Text>
                    </View>
                  </View>
                  
                  <View style={styles.descriptionContainer}>
                    <Text style={styles.descriptionTitle}>Synopsis</Text>
                    <Text style={styles.descriptionText}>
                      {selectedMovie.description}
                    </Text>
                  </View>
                  
                  <View style={styles.actionButtons}>
                    <TouchableOpacity style={styles.watchButton}>
                      <Text style={styles.watchButtonText}>▶ Watch Now</Text>
                    </TouchableOpacity>
                    <TouchableOpacity style={styles.trailerButton}>
                      <Text style={styles.trailerButtonText}>🎬 Trailer</Text>
                    </TouchableOpacity>
                  </View>
                </View>
              </>
            )}
          </ScrollView>
        </View>
      </View>
    </Modal>
  );

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <StatusBar barStyle="dark-content" backgroundColor="#f8f9fa" />
        <View style={styles.loadingAnimation}>
          <ActivityIndicator size="large" color="#667eea" />
          <Text style={styles.loadingText}>Loading amazing movies...</Text>
          <Text style={styles.loadingSubtext}>Getting ready for you 🎬</Text>
        </View>
      </View>
    );
  }

  if (error) {
    return (
      <View style={styles.errorContainer}>
        <StatusBar barStyle="dark-content" backgroundColor="#f8f9fa" />
        <View style={styles.errorContent}>
          <Text style={styles.errorIcon}>🎬</Text>
          <Text style={styles.errorTitle}>Oops! Something went wrong</Text>
          <Text style={styles.errorMessage}>{error}</Text>
          <TouchableOpacity style={styles.retryButton} onPress={fetchMovies}>
            <Text style={styles.retryButtonText}>Try Again</Text>
          </TouchableOpacity>
        </View>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <StatusBar barStyle="light-content" backgroundColor="#1a1a2e" />
      {renderHeader()}
      <FlatList
        data={movies}
        keyExtractor={(item) => item.id}
        renderItem={renderMovieCard}
        contentContainerStyle={styles.listContainer}
        showsVerticalScrollIndicator={false}
      />
      {renderMovieModal()}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8f9fa',
  },
  header: {
    backgroundColor: '#1a1a2e',
    paddingTop: 50,
    paddingBottom: 25,
    borderBottomLeftRadius: 25,
    borderBottomRightRadius: 25,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 5 },
    shadowOpacity: 0.2,
    shadowRadius: 10,
    elevation: 8,
  },
  headerContent: {
    alignItems: 'center',
    paddingHorizontal: 20,
  },
  headerEmoji: {
    fontSize: 55,
    marginBottom: 5,
  },
  headerTitle: {
    fontSize: 32,
    fontWeight: 'bold',
    color: 'white',
    letterSpacing: 1,
    marginTop: 5,
  },
  headerSubtitle: {
    fontSize: 14,
    color: 'rgba(255,255,255,0.8)',
    marginTop: 4,
  },
  statsContainer: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 20,
    paddingHorizontal: 20,
  },
  statBox: {
    alignItems: 'center',
    flex: 1,
  },
  statNumber: {
    fontSize: 22,
    fontWeight: 'bold',
    color: 'white',
  },
  statLabel: {
    fontSize: 11,
    color: 'rgba(255,255,255,0.7)',
    marginTop: 4,
  },
  statDivider: {
    width: 1,
    height: 35,
    backgroundColor: 'rgba(255,255,255,0.2)',
    marginHorizontal: 15,
  },
  listContainer: {
    padding: 16,
  },
  movieCard: {
    flexDirection: 'row',
    backgroundColor: 'white',
    marginBottom: 16,
    borderRadius: 16,
    padding: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.1,
    shadowRadius: 6,
    elevation: 4,
    alignItems: 'center',
  },
  moviePoster: {
    width: 70,
    height: 70,
    borderRadius: 12,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 15,
  },
  moviePosterEmoji: {
    fontSize: 35,
  },
  movieInfo: {
    flex: 1,
  },
  movieHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 6,
  },
  movieNumber: {
    fontSize: 12,
    color: '#667eea',
    fontWeight: '600',
  },
  ratingContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FFF3E0',
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: 12,
  },
  ratingStar: {
    fontSize: 10,
    marginRight: 3,
  },
  ratingText: {
    fontSize: 11,
    fontWeight: 'bold',
    color: '#F5A623',
  },
  movieTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 6,
    lineHeight: 20,
  },
  movieMeta: {
    flexDirection: 'row',
    gap: 8,
  },
  metaBadge: {
    backgroundColor: '#f0f0f0',
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 12,
  },
  metaBadgeText: {
    fontSize: 11,
    color: '#666',
  },
  playIcon: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#667eea',
    justifyContent: 'center',
    alignItems: 'center',
    marginLeft: 10,
  },
  playIconText: {
    fontSize: 18,
    color: 'white',
    fontWeight: 'bold',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#f8f9fa',
  },
  loadingAnimation: {
    alignItems: 'center',
  },
  loadingText: {
    marginTop: 15,
    fontSize: 16,
    color: '#666',
    fontWeight: '500',
  },
  loadingSubtext: {
    marginTop: 8,
    fontSize: 13,
    color: '#999',
  },
  errorContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#f8f9fa',
  },
  errorContent: {
    alignItems: 'center',
    padding: 20,
  },
  errorIcon: {
    fontSize: 64,
    marginBottom: 20,
  },
  errorTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 10,
  },
  errorMessage: {
    fontSize: 14,
    color: '#666',
    textAlign: 'center',
    marginBottom: 20,
  },
  retryButton: {
    backgroundColor: '#667eea',
    paddingHorizontal: 25,
    paddingVertical: 12,
    borderRadius: 25,
  },
  retryButtonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: '600',
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.95)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalContent: {
    width: width - 30,
    maxHeight: height - 60,
    backgroundColor: 'white',
    borderRadius: 20,
    overflow: 'hidden',
  },
  modalClose: {
    position: 'absolute',
    top: 16,
    right: 16,
    zIndex: 1,
    backgroundColor: 'rgba(0,0,0,0.6)',
    width: 36,
    height: 36,
    borderRadius: 18,
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalCloseText: {
    fontSize: 20,
    color: 'white',
    fontWeight: 'bold',
  },
  modalPoster: {
    width: '100%',
    height: 250,
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalPosterEmoji: {
    fontSize: 80,
    marginBottom: 10,
  },
  modalPosterText: {
    fontSize: 16,
    color: 'white',
    fontWeight: 'bold',
    backgroundColor: 'rgba(0,0,0,0.5)',
    paddingHorizontal: 15,
    paddingVertical: 5,
    borderRadius: 20,
  },
  modalInfo: {
    padding: 24,
  },
  modalTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 16,
    textAlign: 'center',
  },
  modalMetaRow: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    marginBottom: 24,
    paddingVertical: 16,
    borderTopWidth: 1,
    borderTopColor: '#f0f0f0',
    borderBottomWidth: 1,
    borderBottomColor: '#f0f0f0',
  },
  modalMetaItem: {
    alignItems: 'center',
    gap: 6,
  },
  modalMetaIcon: {
    fontSize: 20,
  },
  modalMetaText: {
    fontSize: 13,
    color: '#666',
    fontWeight: '500',
  },
  descriptionContainer: {
    marginBottom: 24,
  },
  descriptionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 12,
  },
  descriptionText: {
    fontSize: 14,
    color: '#666',
    lineHeight: 22,
  },
  actionButtons: {
    flexDirection: 'row',
    gap: 12,
    marginBottom: 16,
  },
  watchButton: {
    flex: 1,
    backgroundColor: '#667eea',
    paddingVertical: 14,
    borderRadius: 12,
    alignItems: 'center',
  },
  watchButtonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: 'bold',
  },
  trailerButton: {
    flex: 1,
    backgroundColor: '#f0f0f0',
    paddingVertical: 14,
    borderRadius: 12,
    alignItems: 'center',
  },
  trailerButtonText: {
    color: '#667eea',
    fontSize: 16,
    fontWeight: 'bold',
  },
});