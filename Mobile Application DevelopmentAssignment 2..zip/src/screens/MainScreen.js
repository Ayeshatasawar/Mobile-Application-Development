import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  TextInput,
  FlatList,
  Text,
  StyleSheet,
  TouchableOpacity,
  Alert,
  KeyboardAvoidingView,
  Platform,
  ActivityIndicator,
  Animated,
  StatusBar,
  Modal
} from 'react-native';
import { db, auth } from '../../FirebaseConfig';
import { collection, addDoc, onSnapshot, deleteDoc, doc, query, orderBy, where } from 'firebase/firestore';
import { signOut } from 'firebase/auth';

export default function MainScreen({ navigation }) {
  const [note, setNote] = useState('');
  const [notes, setNotes] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedNote, setSelectedNote] = useState(null);
  const [modalVisible, setModalVisible] = useState(false);
  
  const fadeAnim = useRef(new Animated.Value(0)).current;
  const slideAnim = useRef(new Animated.Value(50)).current;

  useEffect(() => {
    const currentUser = auth.currentUser;
    
    if (!currentUser) {
      navigation.replace('Login');
      return;
    }

    const q = query(
      collection(db, 'notes'), 
      where('userId', '==', currentUser.uid)
    
    );
    
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const notesList = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      // Sort locally instead of using orderBy
      notesList.sort((a, b) => {
        if (a.timestamp && b.timestamp) {
          return b.timestamp.toDate() - a.timestamp.toDate();
        }
        return 0;
      });
      setNotes(notesList);
      setLoading(false);
      
      Animated.parallel([
        Animated.timing(fadeAnim, {
          toValue: 1,
          duration: 500,
          useNativeDriver: true,
        }),
        Animated.timing(slideAnim, {
          toValue: 0,
          duration: 400,
          useNativeDriver: true,
        }),
      ]).start();
    }, (error) => {
      console.error("Error fetching notes:", error);
      setLoading(false);
    });
    return unsubscribe;
  }, []);

  const saveNote = async () => {
    const currentUser = auth.currentUser;
    
    if (!currentUser) {
      Alert.alert('Error', 'Please login again');
      navigation.replace('Login');
      return;
    }
    
    if (!note.trim()) {
      Alert.alert('Error', 'Please write something');
      return;
    }
    
    try {
      await addDoc(collection(db, 'notes'), {
        text: note.trim(),
        userId: currentUser.uid,
        timestamp: new Date(),
        createdAt: new Date().toISOString()
      });
      setNote('');
    } catch (error) {
      Alert.alert('Error', 'Failed to save note');
    }
  };

  const deleteNote = (id) => {
    Alert.alert(
      'Delete Note',
      'Are you sure you want to delete this note?',
      [
        { text: 'Cancel', style: 'cancel' },
        { text: 'Delete', style: 'destructive', onPress: async () => {
          await deleteDoc(doc(db, 'notes', id));
        }}
      ]
    );
  };

  const logout = async () => {
    Alert.alert(
      'Logout',
      'Are you sure you want to logout?',
      [
        { text: 'Cancel', style: 'cancel' },
        { text: 'Logout', style: 'destructive', onPress: async () => {
          await signOut(auth);
          navigation.replace('Login');
        }}
      ]
    );
  };

  const formatDate = (timestamp) => {
    if (!timestamp) return '';
    try {
      const date = timestamp.toDate();
      const now = new Date();
      const diff = now - date;
      const minutes = Math.floor(diff / 60000);
      const hours = Math.floor(minutes / 60);
      const days = Math.floor(hours / 24);

      if (minutes < 1) return 'Just now';
      if (minutes < 60) return `${minutes}m ago`;
      if (hours < 24) return `${hours}h ago`;
      if (days < 7) return `${days}d ago`;
      return date.toLocaleDateString();
    } catch (error) {
      return '';
    }
  };

  const getNoteColor = (index) => {
    const colors = ['#FF6B6B', '#4ECDC4', '#45B7D1', '#96CEB4', '#FFEAA7', '#DDA0DD'];
    return colors[index % colors.length];
  };

  const renderNoteItem = ({ item, index }) => {
    return (
      <Animated.View
        style={[
          styles.noteWrapper,
          {
            opacity: fadeAnim,
            transform: [{ translateY: slideAnim }],
          },
        ]}
      >
        <TouchableOpacity
          style={[styles.noteItem, { borderLeftColor: getNoteColor(index) }]}
          onPress={() => {
            setSelectedNote(item);
            setModalVisible(true);
          }}
          onLongPress={() => deleteNote(item.id)}
          activeOpacity={0.7}
        >
          <View style={styles.noteContent}>
            <View style={styles.noteHeader}>
              <View style={[styles.noteIcon, { backgroundColor: getNoteColor(index) }]}>
                <Text style={styles.noteIconText}>📝</Text>
              </View>
              <TouchableOpacity onPress={() => deleteNote(item.id)}>
                <Text style={styles.deleteIcon}>🗑️</Text>
              </TouchableOpacity>
            </View>
            <Text style={styles.noteText} numberOfLines={2}>
              {item.text}
            </Text>
            <View style={styles.noteFooter}>
              <Text style={styles.noteDate}>{formatDate(item.timestamp)}</Text>
            </View>
          </View>
        </TouchableOpacity>
      </Animated.View>
    );
  };

  return (
    <KeyboardAvoidingView 
      style={styles.container} 
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
    >
      <StatusBar barStyle="light-content" backgroundColor="#0F172A" />
      
      <View style={styles.header}>
        <View>
          <Text style={styles.headerTitle}>My Notes</Text>
          <Text style={styles.headerSubtitle}>
            {notes.length} {notes.length === 1 ? 'note' : 'notes'} saved
          </Text>
        </View>
        <View style={styles.headerButtons}>
          <TouchableOpacity style={styles.moviesBtn} onPress={() => navigation.navigate('Movies')}>
            <Text style={styles.moviesBtnText}>🎬</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.logoutBtn} onPress={logout}>
            <Text style={styles.logoutBtnText}>🚪</Text>
          </TouchableOpacity>
        </View>
      </View>

      <View style={styles.inputSection}>
        <View style={styles.inputWrapper}>
          <TextInput
            placeholder="What's on your mind?"
            placeholderTextColor="#94A3B8"
            value={note}
            onChangeText={setNote}
            style={styles.input}
            multiline
            maxLength={500}
          />
          <TouchableOpacity 
            style={[styles.saveBtn, !note.trim() && styles.saveBtnDisabled]} 
            onPress={saveNote}
            activeOpacity={0.8}
            disabled={!note.trim()}
          >
            <Text style={styles.saveBtnText}>Save Note</Text>
          </TouchableOpacity>
        </View>
      </View>

      <View style={styles.notesContainer}>
        <View style={styles.notesHeader}>
          <Text style={styles.notesTitle}>Recent Notes</Text>
          {notes.length > 0 && (
            <View style={styles.notesCountBadge}>
              <Text style={styles.notesCount}>{notes.length}</Text>
            </View>
          )}
        </View>
        
        {loading ? (
          <View style={styles.loaderContainer}>
            <ActivityIndicator size="large" color="#6366F1" />
            <Text style={styles.loadingText}>Loading your notes...</Text>
          </View>
        ) : (
          <FlatList
            data={notes}
            keyExtractor={item => item.id}
            renderItem={renderNoteItem}
            contentContainerStyle={styles.notesList}
            showsVerticalScrollIndicator={false}
            ListEmptyComponent={
              <View style={styles.emptyState}>
                <View style={styles.emptyIconContainer}>
                  <Text style={styles.emptyIcon}>📝</Text>
                </View>
                <Text style={styles.emptyText}>No notes yet</Text>
                <Text style={styles.emptySubtext}>
                  Start writing your first note!
                </Text>
              </View>
            }
          />
        )}
      </View>

      <Modal
        animationType="slide"
        transparent={true}
        visible={modalVisible}
        onRequestClose={() => setModalVisible(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>Note Details</Text>
              <TouchableOpacity onPress={() => setModalVisible(false)}>
                <Text style={styles.modalClose}>✕</Text>
              </TouchableOpacity>
            </View>
            {selectedNote && (
              <>
                <Text style={styles.modalNoteText}>{selectedNote.text}</Text>
                <Text style={styles.modalDate}>
                  {formatDate(selectedNote.timestamp)}
                </Text>
                <TouchableOpacity 
                  style={styles.modalDeleteBtn}
                  onPress={() => {
                    deleteNote(selectedNote.id);
                    setModalVisible(false);
                  }}
                >
                  <Text style={styles.modalDeleteBtnText}>Delete Note</Text>
                </TouchableOpacity>
              </>
            )}
          </View>
        </View>
      </Modal>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F8FAFC' },
  header: { backgroundColor: '#0F172A', paddingTop: 50, paddingHorizontal: 20, paddingBottom: 25, flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', borderBottomLeftRadius: 25, borderBottomRightRadius: 25, shadowColor: '#000', shadowOffset: { width: 0, height: 5 }, shadowOpacity: 0.1, shadowRadius: 10, elevation: 8 },
  headerTitle: { fontSize: 28, fontWeight: 'bold', color: '#FFFFFF', letterSpacing: 0.5 },
  headerSubtitle: { fontSize: 14, color: '#94A3B8', marginTop: 4 },
  headerButtons: { flexDirection: 'row', gap: 12 },
  moviesBtn: { backgroundColor: 'rgba(255,255,255,0.1)', width: 44, height: 44, borderRadius: 22, justifyContent: 'center', alignItems: 'center', borderWidth: 1, borderColor: 'rgba(255,255,255,0.15)' },
  moviesBtnText: { fontSize: 22 },
  logoutBtn: { backgroundColor: 'rgba(255,255,255,0.1)', width: 44, height: 44, borderRadius: 22, justifyContent: 'center', alignItems: 'center', borderWidth: 1, borderColor: 'rgba(255,255,255,0.15)' },
  logoutBtnText: { fontSize: 22 },
  inputSection: { padding: 20, backgroundColor: '#FFFFFF', borderBottomWidth: 1, borderBottomColor: '#E2E8F0' },
  inputWrapper: { backgroundColor: '#F8FAFC', borderRadius: 20, padding: 5, shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.05, shadowRadius: 5, elevation: 2 },
  input: { borderWidth: 1, borderColor: '#E2E8F0', borderRadius: 16, padding: 15, fontSize: 16, backgroundColor: '#FFFFFF', minHeight: 80, textAlignVertical: 'top', marginBottom: 10, color: '#1E293B' },
  saveBtn: { backgroundColor: '#6366F1', padding: 14, borderRadius: 16, alignItems: 'center', marginHorizontal: 5, marginBottom: 5, shadowColor: '#6366F1', shadowOffset: { width: 0, height: 3 }, shadowOpacity: 0.3, shadowRadius: 5, elevation: 3 },
  saveBtnDisabled: { backgroundColor: '#CBD5E1', shadowOpacity: 0 },
  saveBtnText: { color: '#FFFFFF', fontSize: 16, fontWeight: 'bold', letterSpacing: 0.5 },
  notesContainer: { flex: 1, padding: 20 },
  notesHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 15 },
  notesTitle: { fontSize: 20, fontWeight: 'bold', color: '#1E293B' },
  notesCountBadge: { backgroundColor: '#E0E7FF', paddingHorizontal: 10, paddingVertical: 4, borderRadius: 12 },
  notesCount: { fontSize: 14, color: '#6366F1', fontWeight: '600' },
  notesList: { paddingBottom: 20 },
  noteWrapper: { marginBottom: 12 },
  noteItem: { backgroundColor: '#FFFFFF', borderRadius: 16, shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.08, shadowRadius: 6, elevation: 3, overflow: 'hidden', borderLeftWidth: 4 },
  noteContent: { padding: 16 },
  noteHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 },
  noteIcon: { width: 32, height: 32, borderRadius: 16, justifyContent: 'center', alignItems: 'center' },
  noteIconText: { fontSize: 16 },
  deleteIcon: { fontSize: 18, opacity: 0.5, padding: 5, color: '#94A3B8' },
  noteText: { fontSize: 16, color: '#334155', lineHeight: 24, marginBottom: 12 },
  noteFooter: { flexDirection: 'row', justifyContent: 'flex-end', borderTopWidth: 1, borderTopColor: '#F1F5F9', paddingTop: 10 },
  noteDate: { fontSize: 11, color: '#94A3B8' },
  loaderContainer: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  loadingText: { marginTop: 12, fontSize: 14, color: '#94A3B8' },
  emptyState: { alignItems: 'center', paddingVertical: 80 },
  emptyIconContainer: { width: 80, height: 80, borderRadius: 40, backgroundColor: '#F1F5F9', justifyContent: 'center', alignItems: 'center', marginBottom: 20 },
  emptyIcon: { fontSize: 40, opacity: 0.5 },
  emptyText: { fontSize: 20, color: '#94A3B8', fontWeight: '600', marginBottom: 8 },
  emptySubtext: { fontSize: 14, color: '#CBD5E1' },
  modalOverlay: { flex: 1, backgroundColor: 'rgba(0, 0, 0, 0.5)', justifyContent: 'center', alignItems: 'center' },
  modalContent: { backgroundColor: '#FFFFFF', borderRadius: 24, padding: 24, width: '90%', maxHeight: '80%' },
  modalHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 },
  modalTitle: { fontSize: 20, fontWeight: 'bold', color: '#1E293B' },
  modalClose: { fontSize: 24, color: '#94A3B8', fontWeight: 'bold' },
  modalNoteText: { fontSize: 16, color: '#334155', lineHeight: 24, marginBottom: 16 },
  modalDate: { fontSize: 12, color: '#94A3B8', marginBottom: 20 },
  modalDeleteBtn: { backgroundColor: '#EF4444', padding: 14, borderRadius: 12, alignItems: 'center' },
  modalDeleteBtnText: { color: '#FFFFFF', fontSize: 16, fontWeight: 'bold' },
});