import { initializeApp } from "firebase/app";
import { initializeAuth, getReactNativePersistence } from "firebase/auth";
import { getFirestore } from "firebase/firestore";
import ReactNativeAsyncStorage from '@react-native-async-storage/async-storage';

const firebaseConfig = {
  apiKey: "AIzaSyAba1SqrRcKzIBWDTxi-6HW80GxddxnaSQ",
  authDomain: "myassignment-b302b.firebaseapp.com",
  projectId: "myassignment-b302b",
  storageBucket: "myassignment-b302b.firebasestorage.app",
  messagingSenderId: "1030717079470",
  appId: "1:1030717079470:web:485d00fac86c733025523f",
  measurementId: "G-N7SQH7P4KZ"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

// Initialize Auth with persistence
const auth = initializeAuth(app, {
  persistence: getReactNativePersistence(ReactNativeAsyncStorage)
});

// Initialize Firestore
const db = getFirestore(app);

export { auth, db };