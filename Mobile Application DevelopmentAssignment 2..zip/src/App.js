import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { StatusBar } from 'react-native';
import LoginScreen from './src/screens/LoginScreen';
import MainScreen from './src/screens/MainScreen';
import MovieScreen from './src/screens/MovieScreen';

const Stack = createNativeStackNavigator();

export default function App() {
  return (
    <>
      <StatusBar barStyle="light-content" backgroundColor="#667eea" />
      <NavigationContainer>
        <Stack.Navigator initialRouteName="Login">
          <Stack.Screen 
            name="Login" 
            component={LoginScreen} 
            options={{ headerShown: false }}
          />
          <Stack.Screen 
            name="Main" 
            component={MainScreen} 
            options={{ title: 'My Notes', headerStyle: { backgroundColor: '#667eea' }, headerTintColor: '#fff' }}
          />
          <Stack.Screen 
            name="Movies" 
            component={MovieScreen} 
            options={{ title: 'Trending Movies', headerStyle: { backgroundColor: '#667eea' }, headerTintColor: '#fff' }}
          />
        </Stack.Navigator>
      </NavigationContainer>
    </>
  );
}